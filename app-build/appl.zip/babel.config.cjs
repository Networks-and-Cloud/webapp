// babel.config.js or .babelrc

module.exports = {
  presets: [
    [
      '@babel/preset-env',
    ],
  ],
};
