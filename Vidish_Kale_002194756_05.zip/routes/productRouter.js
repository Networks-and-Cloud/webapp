/*


import { addProduct, getAllProducts, getPublishedProduct } from '../controllers/productController.js' 

const router = require('express').Router()

router.post('/addProduct', addProduct)
router.get('/allProducts', getAllProducts)
router.get('/published', getPublishedProduct)


router.get('/:id',productController.getOneProduct)
router.put('/:id',productController.updateProduct)
router.delete('/:id',productController.deleteProduct)

module.exports = router


*/

